import 'package:flutter/material.dart';

import '../example/lib/home_page.dart';

void main() => runApp(new MaterialApp(
      debugShowCheckedModeBanner: false,
      home: new HomePage(),
    ));
