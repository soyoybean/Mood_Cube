//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"
#import <audio/AudioPlugin.h>
#import <audioplayers/AudioplayersPlugin.h>
#import <flutter_appavailability/AppAvailability.h>
#import <flutter_bluetooth_serial/FlutterBluetoothSerialPlugin.h>
#import <flutter_webview_plugin/FlutterWebviewPlugin.h>
#import <gapless_audio_loop/GaplessAudioLoopPlugin.h>
#import <path_provider/PathProviderPlugin.h>
#import <shared_preferences/SharedPreferencesPlugin.h>
#import <store_redirect/StoreRedirectPlugin.h>
#import <webview_flutter/WebViewFlutterPlugin.h>
#import <youtube_api/YoutubeApiPlugin.h>

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [AudioPlugin registerWithRegistrar:[registry registrarForPlugin:@"AudioPlugin"]];
  [AudioplayersPlugin registerWithRegistrar:[registry registrarForPlugin:@"AudioplayersPlugin"]];
  [AppAvailability registerWithRegistrar:[registry registrarForPlugin:@"AppAvailability"]];
  [FlutterBluetoothSerialPlugin registerWithRegistrar:[registry registrarForPlugin:@"FlutterBluetoothSerialPlugin"]];
  [FlutterWebviewPlugin registerWithRegistrar:[registry registrarForPlugin:@"FlutterWebviewPlugin"]];
  [GaplessAudioLoopPlugin registerWithRegistrar:[registry registrarForPlugin:@"GaplessAudioLoopPlugin"]];
  [FLTPathProviderPlugin registerWithRegistrar:[registry registrarForPlugin:@"FLTPathProviderPlugin"]];
  [FLTSharedPreferencesPlugin registerWithRegistrar:[registry registrarForPlugin:@"FLTSharedPreferencesPlugin"]];
  [StoreRedirectPlugin registerWithRegistrar:[registry registrarForPlugin:@"StoreRedirectPlugin"]];
  [FLTWebViewFlutterPlugin registerWithRegistrar:[registry registrarForPlugin:@"FLTWebViewFlutterPlugin"]];
  [YoutubeApiPlugin registerWithRegistrar:[registry registrarForPlugin:@"YoutubeApiPlugin"]];
}

@end
