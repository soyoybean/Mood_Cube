import 'package:flutter/material.dart';
import 'file:///Users/soyonkim/Downloads/flutter_bluetooth_serial-master%202%20copy%207/example/lib/home_page.dart';

import './MainPage.dart';

void main() => runApp(new ExampleApplication());

class ExampleApplication extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(home: HomePage());
  }
}
